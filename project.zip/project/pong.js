const canvas = document.getElementById('pongCanvas');
const context = canvas.getContext('2d');

const paddleWidth = 10;
const paddleHeight = 100;
let paddle1Y = canvas.height / 2 - paddleHeight / 2;
let paddle2Y = canvas.height / 2 - paddleHeight / 2;
const paddleSpeed = 6;

let ballX = canvas.width / 2;
let ballY = canvas.height / 2;
const ballSize = 10;
let ballSpeedX = 4;
let ballSpeedY = 3;

function drawRect(x, y, width, height, color) {
    context.fillStyle = color;
    context.fillRect(x, y, width, height);
}

function drawCircle(x, y, radius, color) {
    context.fillStyle = color;
    context.beginPath();
    context.arc(x, y, radius, 0, Math.PI * 2, true);
    context.fill();
}

function toggleMenu() {
    const menu = document.getElementById('menu');
    menu.classList.toggle('open');
}

function goToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({ behavior: 'smooth' });
        toggleMenu(); // Close the menu after clicking
    }
}
function draw() {
    drawRect(0, 0, canvas.width, canvas.height, 'black');
    drawRect(0, paddle1Y, paddleWidth, paddleHeight, 'white');
    drawRect(canvas.width - paddleWidth, paddle2Y, paddleWidth, paddleHeight, 'white');
    drawCircle(ballX, ballY, ballSize, 'white');

    ballX += ballSpeedX;
    ballY += ballSpeedY;

    if (ballY + ballSize > canvas.height || ballY - ballSize < 0) {
        ballSpeedY = -ballSpeedY;
    }

    if (ballX + ballSize > canvas.width) {
        if (ballY > paddle2Y && ballY < paddle2Y + paddleHeight) {
            ballSpeedX = -ballSpeedX;
        } else {
            resetBall();
        }
    }

    if (ballX - ballSize < 0) {
        if (ballY > paddle1Y && ballY < paddle1Y + paddleHeight) {
            ballSpeedX = -ballSpeedX;
        } else {
            resetBall();
        }
    }
}

function resetBall() {
    ballX = canvas.width / 2;
    ballY = canvas.height / 2;
    ballSpeedX = -ballSpeedX;
}

function movePaddles() {
    if (ballY > paddle2Y + paddleHeight / 2) {
        paddle2Y += paddleSpeed;
    } else {
        paddle2Y -= paddleSpeed;
    }

    if (paddle1Y < 0) {
        paddle1Y = 0;
    } else if (paddle1Y + paddleHeight > canvas.height) {
        paddle1Y = canvas.height - paddleHeight;
    }

    if (paddle2Y < 0) {
        paddle2Y = 0;
    } else if (paddle2Y + paddleHeight > canvas.height) {
        paddle2Y = canvas.height - paddleHeight;
    }
}

function update() {
    movePaddles();
    draw();
}

setInterval(update, 1000 / 60);

window.addEventListener('keydown', (event) => {
    switch (event.key) {
        case 'ArrowUp':
            paddle1Y -= paddleSpeed;
            break;
        case 'ArrowDown':
            paddle1Y += paddleSpeed;
            break;
    }
});
