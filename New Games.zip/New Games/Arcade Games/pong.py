import pygame
import sys

# Initialize Pygame
pygame.init()

# Screen dimensions
screen_width = 800
screen_height = 600

# Colors
white = (255, 255, 255)
black = (0, 0, 0)

# Paddle dimensions
paddle_width = 10
paddle_height = 100

# Ball dimensions
ball_size = 10

# Create the screen
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Pong")

# Paddle positions
paddle1_y = (screen_height - paddle_height) // 2
paddle2_y = (screen_height - paddle_height) // 2

# Ball position and velocity
ball_x = screen_width // 2
ball_y = screen_height // 2
ball_dx = 4
ball_dy = 4

# Paddle speed
paddle_speed = 6
paddle2_speed = 4  # Speed of the right paddle (AI controlled)

# Main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Get keys pressed
    keys = pygame.key.get_pressed()

    # Move left paddle
    if keys[pygame.K_w] and paddle1_y > 0:
        paddle1_y -= paddle_speed
    if keys[pygame.K_s] and paddle1_y < screen_height - paddle_height:
        paddle1_y += paddle_speed

    # Move right paddle (AI controlled)
    if paddle2_y + paddle_height // 2 < ball_y and paddle2_y < screen_height - paddle_height:
        paddle2_y += paddle2_speed
    elif paddle2_y + paddle_height // 2 > ball_y and paddle2_y > 0:
        paddle2_y -= paddle2_speed

    # Move ball
    ball_x += ball_dx
    ball_y += ball_dy

    # Ball collision with top and bottom
    if ball_y <= 0 or ball_y >= screen_height - ball_size:
        ball_dy = -ball_dy

    # Ball collision with paddles
    if (ball_x <= paddle_width and paddle1_y < ball_y < paddle1_y + paddle_height) or (ball_x >= screen_width - paddle_width - ball_size and paddle2_y < ball_y < paddle2_y + paddle_height):
        ball_dx = -ball_dx

    # Ball goes out of bounds
    if ball_x < 0 or ball_x > screen_width:
        ball_x = screen_width // 2
        ball_y = screen_height // 2
        ball_dx = -ball_dx

    # Fill screen with black
    screen.fill(black)

    # Draw paddles
    pygame.draw.rect(screen, white, (0, paddle1_y, paddle_width, paddle_height))
    pygame.draw.rect(screen, white, (screen_width - paddle_width, paddle2_y, paddle_width, paddle_height))

    # Draw ball
    pygame.draw.rect(screen, white, (ball_x, ball_y, ball_size, ball_size))

    # Update display
    pygame.display.flip()

    # Frame rate
    pygame.time.Clock().tick(60)

# Quit Pygame
pygame.quit()
sys.exit()
