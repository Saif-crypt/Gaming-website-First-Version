import random

def print_board(board):
    for i in range(9):
        if i % 3 == 0 and i != 0:
            print("- - - - - - - - - - - -")
        for j in range(9):
            if j % 3 == 0 and j != 0:
                print(" | ", end="")
            if j == 8:
                print(board[i][j])
            else:
                print(f"{board[i][j]} ", end="")

def find_empty(board):
    for i in range(9):
        for j in range(9):
            if board[i][j] == 0:
                return (i, j)
    return None

def is_valid(board, num, pos):
    # Check row
    for i in range(9):
        if board[pos[0]][i] == num and pos[1] != i:
            return False

    # Check column
    for i in range(9):
        if board[i][pos[1]] == num and pos[0] != i:
            return False

    # Check 3x3 box
    box_x = pos[1] // 3
    box_y = pos[0] // 3
    for i in range(box_y*3, box_y*3 + 3):
        for j in range(box_x*3, box_x*3 + 3):
            if board[i][j] == num:
                return False

    return True

def solve(board):
    empty = find_empty(board)
    if not empty:
        return True
    else:
        row, col = empty

    for i in range(1, 10):
        if is_valid(board, i, (row, col)):
            board[row][col] = i

            if solve(board):
                return True

            board[row][col] = 0

    return False

def generate_puzzle(attempts=5):
    # Start with an empty board
    board = [[0 for _ in range(9)] for _ in range(9)]
    
    # Fill the board with a valid Sudoku solution
    solve(board)

    # Remove numbers to create the puzzle
    for _ in range(attempts):
        row = random.randint(0, 8)
        col = random.randint(0, 8)
        while board[row][col] == 0:
            row = random.randint(0, 8)
            col = random.randint(0, 8)
        board[row][col] = 0

    return board

def check_win(board):
    for row in range(9):
        for col in range(9):
            num = board[row][col]
            if num == 0 or not is_valid(board, num, (row, col)):
                return False
    return True

def play_sudoku():
    board = generate_puzzle()

    while not check_win(board):
        print_board(board)
        try:
            row = int(input("Enter the row (1-9): ")) - 1
            col = int(input("Enter the column (1-9): ")) - 1
            num = int(input("Enter the number (1-9): "))
        except ValueError:
            print("Invalid input! Please enter numbers between 1 and 9.")
            continue
        
        if row not in range(9) or col not in range(9) or num not in range(1, 10):
            print("Invalid move! Row, column, and number must be between 1 and 9.")
            continue
        
        if board[row][col] == 0 and is_valid(board, num, (row, col)):
            board[row][col] = num
        else:
            print("Invalid move. Try again.")

    print("Congratulations! You've completed the Sudoku puzzle!")
    print_board(board)

if __name__ == "__main__":
    play_sudoku()
